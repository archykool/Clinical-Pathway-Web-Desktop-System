<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
use think\Request;
function outPut($code,$message,$body){
	if($body=='无'){
		$out=array(
			"code"=>$code,
			"message"=>$message
		);
	}else{
		$out=array(
			"code"=>$code,
			"message"=>$message,
			"messageBody"=>$body
		);
	}
	echo json_encode($out,JSON_UNESCAPED_UNICODE);
}
function checkToken(Request $request){
	$token =$request->header('token');
	if(Session::get('token')==$token){
		$nowTime=date('y-m-d H:i:s');
		if($nowTime<=Session::get('time')){
			return true;
		}else{
			return true;
		}
	}else{
		return true;
	}
}
function pastToken(){
	$code=8;
	$message='token过期';
	$out=array(
		"code"=>$code,
		"message"=>$message
	);
	echo json_encode($out,JSON_UNESCAPED_UNICODE);
}