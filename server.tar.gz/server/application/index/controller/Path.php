<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
class Path extends Controller
{  
   	private $body='无';
    //初始化路径模板 
   	public function indexPath(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			if(array_key_exists('pathName',$data)){
   				$where[]=['pathName','like','%'.$data["pathName"].'%'];
   			}
   			if(array_key_exists('pathDept',$data)){
   				$where[]=['pathDept','like','%'.$data["pathDept"].'%'];
   			}
   			$where[]=['pathID','>',-1];
   			$result=Db::table('Path')->field('pathID,pathCode,pathDept,pathName,pathCrtstaff,pathVer')->where($where)->select();
   			//print_r($result);
   			$code=0;
   			$message='查询成功';
   			$this->body=$result;
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
    //添加路径模板 
   	public function addPathTemplate(Request $request){	
   		if(checkToken($request)){
   			$data=$request->param();
   			$nowTime=date('Y-m-d H:i:s');
   			$data["pathTimestamp"]=$nowTime;
   			Db::table('Path')->insert($data);
   			$code=0;
   			$message='添加成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
    //删除路径模板
   	public function deletePathTemplate(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
            Db::table('Path')->delete($data);
   			$code=0;
   			$message='删除成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//添加环节
   	public function addLink(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			Db::table('Pathseg')->insert($data);
   			$code=0;
   			$message='添加环节成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//删除环节
   	public function deleteLink(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			Db::table('Pathseg')->where($data)->delete();
   			$code=0;
   			$message='删除环节成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//修改环节
   	public function updateLink(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			$PathsegID=$data["pathsegID"];
   			$pathsegDay=$data["pathsegDay"];
   			Db::table('Pathseg')->where('PathsegID',$PathsegID)->update(['pathsegDay'=>$pathsegDay]);
   			$code=0;
   			$message='修改环节成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//添加诊疗内容
   	public function addTreatment(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			Db::table('Item')->insert($data);
   			$code=0;
   			$message='添加诊疗内容成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//删除诊疗内容
   	public function deleteTreatment(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			Db::table('Item')->where($data)->delete();
   			$code=0;
   			$message='删除诊疗内容成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//修改诊疗内容
   	public function updateTreatment(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			$itemID=$data["itemID"];
   			$itemCat=$data["itemCat"];
   			$itemName=$data["itemName"];
   			Db::table('Item')->where('itemID',$itemID)->update(['itemCat'=>$itemCat,'itemName'=>$itemName]);
   			$code=0;
   			$message='修改诊疗内容成功';
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//初始化路径模板细节
   	public function pathinfoIndex(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			$pathID=$data["pathID"];
   			$result=Db::table('Path')->field('pathID,pathName,pathCode,pathDept,pathReq,pathSlos,pathCrtstaff')->where('pathID',$pathID)->select();
   			//print_r($result);
   			$result1=Db::table('Pathseg')->field('pathsegID,pathsegDay')->order('pathsegDay')->where('pathID',$pathID)->select();
   			$code=0;
   			$message='查询成功';
   			$this->body=array(
   				"title"=>$result[0],
   				"content"=>$result1
   			);
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
   	//查询诊疗内容
   	public function selectTreatment(Request $request){
   		if(checkToken($request)){
   			$data=$request->param();
   			$pathsegID=$data["pathsegID"];
   			$result=Db::table('Item')->field('itemID,itemCat,itemName')->where('pathsegID',$pathsegID)->select();
   			$code=0;
   			$message='查询成功';
   			$this->body=$result;
   			outPut($code,$message,$this->body);
   		}else{
   			pastToken();
   		}
   	}
}