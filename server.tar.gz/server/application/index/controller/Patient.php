<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
class Patient extends Controller
{   
	private $body='无';
    //查询疾病种类
    public function diseaseType(Request $request){
    	if(checkToken($request)){
    		$result=Db::table('Path')->field('pathID,pathName')->select();
    		$code=0;
    		$message='查询成功';
    		$this->body=$result;
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //添加患者基本信息
    public function addPatient(Request $request){
    	if(checkToken($request)){
    		$data=$request->param();
    		$pathID=$data["pathID"];
    		$type=$data["type"];
    		unset($data["pathID"]);
    		unset($data["type"]);
    		$ptID=Db::table('Patient')->insertGetId($data);
    		$result=Db::query("select pathVer,pathDept,pathName from Path where pathID=$pathID");
    		$result=$result[0];
    		$data1=["ptID"=>$ptID,"pathID"=>$pathID,"pathVer"=>$result["pathVer"],"ptpathEntrdept"=>$result["pathDept"],"ptpathName"=>$result["pathName"]];
    		if($type==1){
    			$data1["ptpathEntrdate"]=$data["ptStartdate"];
    		}
    		Db::table('Ptpath')->insert($data1);
    		$code=0;
    		$message='添加患者成功';
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //删除患者
    public function deletePatient(Request $request){
    	if(checkToken($request)){
    		$data=$request->param();
    		Db::table('Patient')->delete($data);
    		$code=0;
    		$message='删除患者成功';
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //患者路径管理初始化
    public function selectPatient(Request $request){
    	if(checkToken($request)){
    		$data=$request->param();
    		if (array_key_exists('ptName',$data)){
    			$where[]=['a.ptName','like','%'.$data['ptName'].'%'];
    		}
    		if(array_key_exists('ptpathEntrdept',$data)){
    			$where[]=['b.ptpathEntrdept','like','%'.$data["ptpathEntrdept"].'%'];
    		}
    		if(array_key_exists('ptpathName',$data)){
    			$where[]=['b.ptpathName','like','%'.$data["ptpathName"].'%'];
    		}
    		if(array_key_exists('ptPathcond',$data)){
    			$where[]=['a.ptPathcond','=',$data["ptPathcond"]];
    		}
    		$where[]=['a.ptID','>',-1];
    		$result=Db::table('Patient')->field(['a.ptID','b.ptpathID','a.ptPathcond','a.ptStartdate','a.ptName','a.ptGender','a.ptAge','b.ptpathName'])->alias('a')->join('Ptpath b','a.ptID = b.ptID')->where($where)->select();
    		$code=0;
            $message='查询成功';
            $this->body=$result;
            outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //患者详细信息
    public function patientInfo(Request $request){
    	if(checkToken($request)){
    		$data=$request->param();
    		$ptID=$data["ptID"];
    		$where[]=['a.ptID','=',$ptID];
    		$result=Db::table('Patient')->field('a.*,b.ptpathEntrdept,b.pathID,b.ptpathID,c.pathName,c.pathSlos')->alias('a')->join('Ptpath b','a.ptID = b.ptID')->join('Path c','b.pathID = c.pathID')->where($where)->select();
    		$pathID=$result[0]["pathID"];
    		$ptpathID=$result[0]["ptpathID"];
    		//print_r($pathID);
    		$result1=Db::table('Pathseg')->field('pathsegID,pathsegDay')->where(['pathID'=>$pathID])->order('pathsegDay')->select();
    		//print_r($result1);
    		for($i=0;$i<count($result1);$i++){
    			$pathsegID=$result1[$i]["pathsegID"];
    			$result0=Db::table('Ptpathseg')->field('ptpathsegTemp,ptitemExecrem')->where(['pathsegID'=>$pathsegID,'ptpathID'=>$ptpathID])->select();
    			if(count($result0)!=0){
    				$result1[$i]["ptpathsegTemp"]=$result0[0]["ptpathsegTemp"];
    				$result1[$i]["ptitemExecrem"]=$result0[0]["ptitemExecrem"];
    			}else{
    				$result1[$i]["ptpathsegTemp"]='无';
    				$result1[$i]["ptitemExecrem"]='无';
    			}
    			$result2=Db::table('Item')->field('itemID,pathsegID,itemCat')->group('itemCat')->where(['pathsegID'=>$pathsegID])->select();
    			for($a=0;$a<count($result2);$a++){
    				$itemCat=$result2[$a]["itemCat"];
    				$result3=Db::table('Item')->where(['pathsegID'=>$pathsegID,'itemCat'=>$itemCat])->order('itemName')->select();
    				for($b=0;$b<count($result3);$b++){
    					$itemID=$result3[$b]["itemID"];
    					$result4=Db::table('Ptitem')->where(['itemID'=>$itemID,'ptpathID'=>$ptpathID])->select();
    					if(count($result4)==0){
    						$result3[$b]["state"]=0;
    						$result3[$b]["ptitemID"]='无';
    					}else{
                            if($result4[0]["ptitemExeccond"]==0){
                                $result3[$b]["state"]=0;
                                $result3[$b]["ptitemID"]=$result4[0]["ptitemID"];
                            }else{
                                $result3[$b]["state"]=1;
                                 $result3[$b]["ptitemID"]=$result4[0]["ptitemID"];
                            }
    						
    					}
                        $result3[$b]["ptpathID"]=$ptpathID;
                        $result3[$b]["itemID"]=$itemID;
    				}
    				$result2[$a]["item"]=$result3;
    			}
    			$result1[$i]["group"]=$result2;
    		}
    		$content=$result1;
    		$code=0;
    		$message='查询成功';
    		$this->body=array(
    			"info"=>$result[0],
    			"content"=>$content
    		);
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //变异操作
    public function mutations(Request $request){
    	if(checkToken($request)){
    		$data=$request->param();
    		$ptpathID=$data["ptpathID"];
    		$ptpathVarrsn=$data["ptpathVarrsn"];
    		$nowTime=date('Y-m-d H:i:s');
    		Db::table('Ptpath')->where(['ptpathID'=>$ptpathID])->update(['ptpathVarrsn'=>$ptpathVarrsn,'ptpathVardate'=>$nowTime,'ptpathDepttype'=>'变异']);
    		$result=Db::table('Ptpath')->where(['ptpathID'=>$ptpathID])->select();
    		$ptID=$result[0]["ptID"];
    		Db::table('Patient')->where(['ptID'=>$ptID])->update(['ptPathcond'=>2]);
    		$code=0;
    		$message='变异完成';
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //完成操作
    public function complete(Request $request){
    	if(checkToken($request)){
    		$data=$request->param();
    		$ptpathID=$data["ptpathID"];
    		$nowTime=date('Y-m-d H:i:s');
    		$result=Db::table('Ptpath')->where(['ptpathID'=>$ptpathID])->select();
    		if($result[0]["ptpathDepttype"]!='变异'){
    			Db::table('Ptpath')->where(['ptpathID'=>$ptpathID])->update(['ptpathDeptdate'=>$nowTime,'ptpathDepttype'=>'完成']);
    		}
    		$ptID=$result[0]["ptID"];
    		Db::table('Patient')->where(['ptID'=>$ptID])->update(['ptPathcond'=>2,'ptEnddate'=>$nowTime]);
    		$code=0;
    		$message='已完成';
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}	
    }
    //修改病人表单
    public function updatePatientForm(Request $request){
        if(checkToken($request)){
            $data1=$request->param();
            for($a=0;$a<count($data1);$a++){
                 //print_r($data);
                $data=$data1[$a];
                $ptpathID=$data["ptpathID"];
                $pathsegID=$data["pathsegID"];
                $item=$data["item"];
                //添加备注、温度
                if(array_key_exists('ptpathsegTemp',$data)||array_key_exists('ptitemExecrem',$data)){
                    unset($data["item"]);
                    $insert=$data;
                    $update=$data;
                    unset($update["ptpathID"]);
                    unset($update["pathsegID"]);
                    $result=Db::table('Ptpathseg')->where(['ptpathID'=>$ptpathID,'pathsegID'=>$pathsegID])->select();
                    if(count($result)==0){
                        Db::table('Ptpathseg')->insert($insert);
                    }else{
                        Db::table('Ptpathseg')->where(['ptpathID'=>$ptpathID,'pathsegID'=>$pathsegID])->update($update);
                    }
                }
                //表单
                for ($i=0;$i<count($item);$i++) { 
                    $ptitemID=$item[$i]["ptitemID"];
                    $itemID=$item[$i]["itemID"];
                    $ptpathID=$item[$i]["ptpathID"];
                    if($i==0){
                        Db::table('Ptitem')->where(['itemID'=>$itemID,'ptpathID'=>$ptpathID])->update(['ptitemExeccond'=>0]);
                    }
                    if($ptitemID=='无'){
                        Db::table('Ptitem')->insert(['itemID'=>$itemID,'ptpathID'=>$ptpathID,'ptitemExeccond'=>1]);
                    }else{
                        Db::table('Ptitem')->where('ptitemID',$ptitemID)->update(['ptitemExeccond'=>1]);
                    }
                }
            }
            $code=0;
            $message='修改成功';
            outPut($code,$message,$this->body);
        }else{
            pastToken();
        }
    }
}