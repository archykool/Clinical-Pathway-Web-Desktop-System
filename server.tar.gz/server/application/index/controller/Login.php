<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\captcha\Captcha;
class Login extends Controller
{   
	private $body='无';
    public function productCode(){
    	$captcha = new Captcha();
        $a=$captcha->entry();
        //var_dump($a); 
        return $a;
    }
    private function checkCode($code){
    	 if(!captcha_check($code)){
            return false;
        }else{
        	return true;
        }
    }
    public function login(Request $request){
    	$data=$request->param();
    	$user=$data["user"];
    	$pass=$data["pass"];
    	$code=$data["code"];
    	$body='无';
    	if($this->checkCode($code)){
    		$result = Db::query("select * from User where userName='$user'");
    		if(count($result)!=0){
    			$result = Db::query("select userID,userName,userType from User where userPwd='$pass'");
    			if(count($result)!=0){
    				$code=0;
    				$message='登录成功';
                    $token=$this->productToken();
                    $result[0]["token"]=$token;
    				$this->body=$result[0];
    			}else{
    				$code=3;
    				$message='密码错误';
    			}
    		}else{
    			$code=2;
    			$message='用户名错误';	
    		}
    	}else{
    		$code=1;
    		$message='验证码错误';
    	}
    	outPut($code,$message,$this->body);
    }
    private function productToken(){
        $len=64;
        $chars = array(
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",
        "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
        "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",
        "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
         "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",
         "3", "4", "5", "6", "7", "8", "9"
        );
        $charsLen = count($chars) - 1;
        shuffle($chars);                            //打乱数组顺序
        $str = '';
        for($i=0; $i<$len; $i++){
            $str .= $chars[mt_rand(0, $charsLen)];    //随机取出一位
        }
        $nowTime=date('y-m-d H:i:s',strtotime("30 minute"));
        Session('token',$str);
        Session('time',$nowTime);
        return $str;
    }
}