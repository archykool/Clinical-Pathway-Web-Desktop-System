<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\captcha\Captcha;
class Register extends Controller
{   
    //添加用户
    public function product(Request $request){
    	$data=$request->param();
        $user=$data["user"];
        $pass=$data["pass"];
        $type=$data["type"];
        $result = Db::query("select * from User where userName='$user'");
            if(count($result)==0){
                $result = Db::execute("INSERT INTO User (userName,userType,userPwd)VALUES('$user',$type,'$pass')");
            if($result!=0){
                $code=0;
                $message='插入成功';
            }else{
                $code=1;
                $message='插入失败';
            }
        }else{
            $code=2;
            $message='用户名重复';
        }
        $body='无';
        outPut($code,$message,$body);
    }
}