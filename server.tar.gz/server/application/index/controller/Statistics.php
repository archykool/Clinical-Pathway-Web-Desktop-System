<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Request;
class Statistics extends Controller
{   
    private  $body='无';
    //路径使用率
    public function usageRate(Request $request){
    	if(checkToken($request)){
    		$result=Db::table('Ptpath')->field('pathID,ptpathName')->group('pathID')->select();
    		//print_r($result);
    		for ($i=0;$i<count($result);$i++){
    			$pathID=$result[$i]['pathID'];
    			$result1=Db::query("select count(pathID) from Ptpath where pathID=$pathID");
    			$result2=Db::query("select count(pathID) from Ptpath where pathID=$pathID and ptpathEntrdate is not null");
    			// $result1=$result1[0]["count(pathID)"];
    			// $result2=$result2[0]["count(pathID)"];
    			// print_r($result1);
    			// print_r($result2);
    			$usageRate=$result2[0]["count(pathID)"]/$result1[0]["count(pathID)"];
    			$usageRate=round($usageRate,3)*100;
    			$usageRate=$usageRate.'%';
    			$result[$i]["usageRate"]=$usageRate;
    		}
    		$code=0;
    		$message='查询成功';
    		$this->body=$result;
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
    //变异率
    public function mutationRate(Request $request){
    	if(checkToken($request)){
    		$result=Db::table('Ptpath')->field('pathID,ptpathName')->group('pathID')->select();
    		for($i=0;$i<count($result);$i++){
    			$pathID=$result[$i]['pathID'];
    			$result1=Db::query("select count(pathID) from Ptpath where pathID=$pathID and ptpathEntrdate is not null");
    			$result2=Db::query("select count(pathID) from Ptpath where pathID=$pathID and ptpathEntrdate is not null and ptpathDepttype='变异'");
    			$mutationRate=$result2[0]["count(pathID)"]/$result1[0]["count(pathID)"];
    			$mutationRate=round($mutationRate,3)*100;
    			$mutationRate=$mutationRate.'%';
    			$result[$i]["mutationRate"]=$mutationRate;
    		}
    		$code=0;
    		$message='查询成功';
    		$this->body=$result;
    		outPut($code,$message,$this->body);
    	}else{
    		pastToken();
    	}
    }
}