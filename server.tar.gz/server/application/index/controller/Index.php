<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
class Index extends Controller
{   
    public function index(Request $request){
    	echo '我是原生控制器';
    }
}